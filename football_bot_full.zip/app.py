import json
import os
from flask import Flask, request
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler
from threading import Thread

TOKEN = os.environ.get('TOKEN')
OWNER_ID = int(os.environ.get('OWNER_ID', '0'))

TEAMS_FILE = 'teams.json'
MATCHES_FILE = 'matches.json'
USERS_FILE = 'users.json'
ADMINS_FILE = 'admins.json'

app = Flask(__name__)

def load_data(file):
    if os.path.exists(file):
        with open(file, 'r') as f:
            return json.load(f)
    return {}

def save_data(file, data):
    with open(file, 'w') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def is_admin(user_id):
    admins = load_data(ADMINS_FILE).get("admins", [])
    return user_id == OWNER_ID or user_id in admins

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[InlineKeyboardButton("📊 جدول لیگ", callback_data='table')],
                [InlineKeyboardButton("⚽ مسابقات امروز", callback_data='matches')],
                [InlineKeyboardButton("🏆 برترین گلزنان", callback_data='topscorer')]]
    await update.message.reply_text("به ربات پیش‌بینی لیگ خوش آمدید!", reply_markup=InlineKeyboardMarkup(keyboard))

async def addteam(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id): return
    if len(context.args) != 1:
        await update.message.reply_text("استفاده: /addteam نام‌تیم")
        return
    data = load_data(TEAMS_FILE)
    team = context.args[0]
    if team in data:
        await update.message.reply_text("این تیم موجود است.")
    else:
        data[team] = {"players": []}
        save_data(TEAMS_FILE, data)
        await update.message.reply_text(f"تیم {team} اضافه شد.")

async def teams(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = load_data(TEAMS_FILE)
    await update.message.reply_text("لیست تیم‌ها:
" + '
'.join(data.keys()))

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data == 'table':
        await query.edit_message_text("📊 جدول لیگ در دست ساخت است.")
    elif query.data == 'matches':
        await query.edit_message_text("⚽ لیست مسابقات امروز در دست ساخت است.")
    elif query.data == 'topscorer':
        await query.edit_message_text("🏆 برترین گلزنان در دست ساخت است.")

def run_bot():
    app_telegram = ApplicationBuilder().token(TOKEN).build()
    app_telegram.add_handler(CommandHandler('start', start))
    app_telegram.add_handler(CommandHandler('addteam', addteam))
    app_telegram.add_handler(CommandHandler('teams', teams))
    app_telegram.add_handler(CallbackQueryHandler(button_handler))
    app_telegram.run_polling()

@app.route('/')
def home():
    return "ربات فعال است!"

if __name__ == '__main__':
    Thread(target=run_bot).start()
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 10000)))